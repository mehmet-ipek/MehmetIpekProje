(function(){
  if (!window.chartData) return;
  const ctx = document.getElementById('vehicleChart');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: window.chartData.labels,
      datasets: [{
        label: 'Araç',
        data: window.chartData.counts,
        fill: true,
        borderColor: '#0d6efd',
        backgroundColor: 'rgba(13,110,253,0.1)',
        tension: 0.3
      }]
    },
    options: { plugins:{legend:{display:false}} }
  });
})();