<?php
require_once __DIR__ . '/../app/Core/Database.php';
require_once __DIR__ . '/../app/Core/Model.php';
require_once __DIR__ . '/../app/Core/Controller.php';

// Controller dosyaları
require_once __DIR__ . '/../app/Controllers/DashboardController.php';
require_once __DIR__ . '/../app/Controllers/VehicleController.php';
require_once __DIR__ . '/../app/Controllers/SketchController.php';
require_once __DIR__ . '/../app/Controllers/RecordController.php';

// Model dosyaları
require_once __DIR__ . '/../app/Models/Vehicle.php';
require_once __DIR__ . '/../app/Models/Record.php';
require_once __DIR__ . '/../app/Models/Sketch.php';

$route = $_GET['route'] ?? 'dashboard';

switch ($route) {
  case 'dashboard':
    (new \App\Controllers\DashboardController())->index();
    break;

  case 'vehicle-entry':
    $ctrl = new \App\Controllers\VehicleController();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') $ctrl->store();
    else $ctrl->create();
    break;

  case 'vehicle-exit':
    $ctrl = new \App\Controllers\VehicleController();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') $ctrl->exitStore();
    else $ctrl->exitForm();
    break;
	
  case 'sketch-view':
	(new \App\Controllers\SketchController())->view();
	break;

  case 'inside-list':
    (new \App\Controllers\VehicleController())->insideList();
    break;

  case 'history':
    (new \App\Controllers\RecordController())->history();
    break;

  case 'logout':
    header('Location: ?route=dashboard'); exit;

  default:
    http_response_code(404);
    echo 'Not Found';
}