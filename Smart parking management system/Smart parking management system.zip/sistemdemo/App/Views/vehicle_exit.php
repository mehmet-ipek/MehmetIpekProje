<div class="mb-2 text-muted">Anasayfa / Araç Çıkışı Yap</div>
<div class="card border-0 shadow-sm">
  <div class="card-body">
    <?php if (!empty($_GET['done'])): ?>
      <div class="alert alert-success">Araç çıkışı kaydedildi.</div>
    <?php endif; ?>
    <form method="post" action="?route=vehicle-exit">
      <div class="mb-3">
        <label class="form-label">Plaka Seç</label>
        <select name="plate" class="form-select" required>
          <?php foreach ($inside as $v): ?>
            <option value="<?= htmlspecialchars($v['plate']) ?>">
              <?= htmlspecialchars($v['plate']) ?> (<?= $v['spot_code'] ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <button class="btn btn-danger">Çıkış Yap</button>
    </form>
  </div>
</div>