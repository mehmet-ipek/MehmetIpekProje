<div class="mb-2 text-muted">Anasayfa / Otopark Kroki Görünümü</div>
<div class="card border-0 shadow-sm">
  <div class="card-body">
    <h5 class="mb-3">Otopark Kroki Görünümü</h5>
    <div class="d-flex flex-wrap gap-3">
      <?php foreach ($spots as $s): ?>
        <div class="text-center p-3 rounded" style="width:100px; background-color:<?= $s['status']=='dolu' ? '#dc3545' : '#198754' ?>; color:white;">
          <?= htmlspecialchars($s['code']) ?><br>
          <?= $s['status']=='dolu' ? 'Dolu' : 'Boş' ?>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="mt-4">
      <span class="badge bg-success">🟩 Boş Alan</span>
      <span class="badge bg-danger">🟥 Dolu Alan</span>
    </div>
  </div>
</div>