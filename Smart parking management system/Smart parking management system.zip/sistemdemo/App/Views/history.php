<div class="mb-2 text-muted">Anasayfa / Geçmiş Kayıtları İncele</div>
<div class="card border-0 shadow-sm">
  <div class="card-body">
    <form class="row g-3 mb-3" method="get">
      <input type="hidden" name="route" value="history">
      <div class="col-md-4">
        <label class="form-label">Başlangıç Tarihi</label>
        <input type="date" name="from" class="form-control" value="<?= htmlspecialchars($from ?? '') ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Bitiş Tarihi</label>
        <input type="date" name="to" class="form-control" value="<?= htmlspecialchars($to ?? '') ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Plaka</label>
        <input type="text" name="plate" class="form-control" placeholder="Plaka" value="<?= htmlspecialchars($plate ?? '') ?>">
      </div>
      <div class="col-12">
        <button class="btn btn-primary">Filtrele</button>
      </div>
    </form>

    <table class="table">
      <thead>
        <tr>
          <th>Plaka</th>
          <th>İçeride Geçirilen Süre</th>
          <th>Giriş Tarihi</th>
          <th>Çıkış Tarihi</th>
          <th>Park Edilen Alan</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r):
          $mins = (int)$r['mins']; $h = intdiv($mins,60); $m=$mins%60;
          $dur = ($h>0 ? "$h Saat " : "") . "$m Dakika";
        ?>
        <tr>
          <td><?= htmlspecialchars($r['plate']) ?></td>
          <td><?= $dur ?></td>
          <td><?= htmlspecialchars($r['entry_at']) ?></td>
          <td><?= htmlspecialchars($r['exit_at']) ?></td>
          <td><?= htmlspecialchars($r['spot_code']) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($rows)): ?>
          <tr><td colspan="5">Kayıt yok.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>