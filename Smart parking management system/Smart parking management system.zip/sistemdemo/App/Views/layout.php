<?php
// Basic Bootstrap layout resembling the screenshots
?>
<!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <title>Akıllı Otopark Uygulaması</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="d-flex">
  <aside class="bg-dark text-white p-3" style="width:260px; min-height:100vh;">
    <h5 class="mb-4">Akıllı Otopark Uygulaması</h5>
    <nav class="nav flex-column gap-2">
      <a class="nav-link text-white" href="?route=dashboard">Anasayfa</a>
      <a class="nav-link text-white" href="?route=vehicle-entry">Araç Girişi Yap</a>
      <a class="nav-link text-white" href="?route=vehicle-exit">Araç Çıkışı Yap</a>
	  <a class="nav-link text-white" href="?route=sketch-view">Kroki Görünümü</a>
      <a class="nav-link text-white" href="?route=inside-list">İçerdeki Araçları Listele</a>
      <a class="nav-link text-white" href="?route=history">Geçmiş Kayıtları İncele</a>
    </nav>
  </aside>
  <main class="flex-grow-1">
    <div class="bg-white border-bottom d-flex align-items-center justify-content-between p-3">
      <form class="d-flex" method="get" action="">
        <input type="hidden" name="route" value="dashboard">
        <input name="q" type="text" class="form-control me-2" placeholder="Plaka Ara..." value="<?= htmlspecialchars($searchQ ?? '') ?>">
        <button class="btn btn-outline-primary">Ara</button>
      </form>
      <a class="btn btn-outline-danger" href="?route=logout">Çıkış</a>
    </div>
    <div class="p-4">
      <?php require $contentView; ?>
    </div>
  </main>
</div>
<script src="assets/js/app.js"></script>
</body>
</html>