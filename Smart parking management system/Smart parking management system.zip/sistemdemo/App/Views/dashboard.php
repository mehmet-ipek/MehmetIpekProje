<div class="row g-4 mb-4">
  <div class="col-md-6">
    <div class="card border-0 shadow-sm">
      <div class="card-body" style="border-left:6px solid #0d6efd;">
        <h5 class="text-primary"><?= $insideCount ?> / <?= $capacity ?> Otoparktaki Araç Sayısı</h5>
        <a class="btn btn-primary mt-2" href="?route=inside-list">Detayları Görüntüle</a>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card border-0 shadow-sm">
      <div class="card-body" style="border-left:6px solid #ffc107;">
        <h5 class="text-warning"><?= $totalEntries ?> Bugüne Kadar Giriş Yapan Araç Sayısı</h5>
        <a class="btn btn-warning mt-2" href="?route=history">Detayları Görüntüle</a>
      </div>
    </div>
  </div>
</div>

<?php if (!empty($searchQ)): ?>
  <div class="card border-0 shadow-sm mt-4">
    <div class="card-body">
      <h6>"<?= htmlspecialchars($searchQ) ?>" araması için sonuçlar</h6>
      <table class="table table-sm">
        <thead><tr><th>Plaka</th><th>Park Yeri</th><th>Giriş Tarihi</th></tr></thead>
        <tbody>
          <?php foreach ($searchRes as $r): ?>
            <tr>
              <td><?= htmlspecialchars($r['plate']) ?></td>
              <td><?= htmlspecialchars($r['spot_code']) ?></td>
              <td><?= htmlspecialchars($r['entry_at']) ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($searchRes)): ?>
            <tr><td colspan="3">Sonuç yok.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endif; ?>