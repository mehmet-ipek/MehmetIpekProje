<div class="mb-2 text-muted">Anasayfa / İçerdeki Araçları Listele</div>
<div class="card border-0 shadow-sm">
  <div class="card-body">
    <table class="table">
      <thead><tr>
        <th>Plaka</th>
        <th>İçeride Geçirilen Süre</th>
        <th>Giriş Tarihi</th>
        <th>Park Edilen Alan</th>
      </tr></thead>
      <tbody>
      <?php foreach ($rows as $r): 
        $mins = (int)$r['mins'];
        $h = intdiv($mins, 60); $m = $mins % 60;
        $dur = ($h>0 ? "$h Saat " : "") . "$m Dakika";
      ?>
        <tr>
          <td><?= htmlspecialchars($r['plate']) ?></td>
          <td><?= $dur ?></td>
          <td><?= htmlspecialchars($r['entry_at']) ?></td>
          <td><?= htmlspecialchars($r['spot_code']) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($rows)): ?>
        <tr><td colspan="4">Kayıt yok.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
    <nav>
      <ul class="pagination">
        <li class="page-item <?= $page<=1?'disabled':'' ?>"><a class="page-link" href="?route=inside-list&page=<?= $page-1 ?>">Previous</a></li>
        <li class="page-item active"><span class="page-link"><?= $page ?></span></li>
        <li class="page-item <?= $page>=$pages?'disabled':'' ?>"><a class="page-link" href="?route=inside-list&page=<?= $page+1 ?>">Next</a></li>
      </ul>
    </nav>
  </div>
</div>