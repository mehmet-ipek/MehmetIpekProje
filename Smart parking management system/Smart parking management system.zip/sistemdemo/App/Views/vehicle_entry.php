<div class="mb-2 text-muted">Anasayfa / Araç Girişi Yap</div>
<div class="card border-0 shadow-sm">
  <div class="card-body">
    <?php if (!empty($_GET['saved'])): ?>
      <div class="alert alert-success">Kayıt yapıldı.</div>
    <?php endif; ?>
    <?php if (!empty($_GET['error'])): ?>
      <div class="alert alert-danger">Bu plaka zaten içeride veya park yeri dolu veya kapasite dolmuş! </div>
    <?php endif; ?>
    <form method="post" action="?route=vehicle-entry">
      <div class="mb-3">
        <label class="form-label">Plaka</label>
        <input name="plate" class="form-control" placeholder="Lütfen Plakayı Giriniz" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Park Yeri</label>
        <select name="spot" class="form-select" required>
          <?php foreach ($spots as $s): ?>
            <option value="<?= htmlspecialchars($s['code']) ?>"><?= htmlspecialchars($s['code']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <button class="btn btn-success">Kaydet</button>
    </form>
  </div>
</div>