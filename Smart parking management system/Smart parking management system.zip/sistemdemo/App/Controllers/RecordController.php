<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Record;

class RecordController extends Controller {
  public function history() {
    $from  = $_GET['from'] ?? null;
    $to    = $_GET['to'] ?? null;
    $plate = $_GET['plate'] ?? null;
    $rows  = (new Record())->historyFiltered($from, $to, $plate);
    $this->render('history', compact('from','to','plate','rows'));
  }
}