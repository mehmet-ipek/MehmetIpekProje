<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Vehicle;
use App\Models\Record;

class DashboardController extends Controller {
  public function index() {
    $vehicle = new Vehicle();
    $record  = new Record();

    $insideCount = $vehicle->countInside();
    $capacity    = $vehicle->capacity();
    $totalEntries= $record->totalEntries();
    $chartData   = $record->dailyCountsForChart();

    $searchQ = $_GET['q'] ?? null;
    $searchRes = $searchQ ? $vehicle->searchPlate($searchQ) : [];

    $this->render('dashboard', compact('insideCount','capacity','totalEntries','chartData','searchQ','searchRes'));
  }
}