<?php
namespace App\Controllers;

use App\Models\Vehicle;
use App\Core\Controller;

class SketchController extends Controller {
  public function view() {
    $vehicle = new Vehicle();
    $spots = $vehicle->spotStatus();
    $this->render('sketch_view', compact('spots'));
  }
}