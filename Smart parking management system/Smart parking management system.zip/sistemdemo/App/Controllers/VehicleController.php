<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Vehicle;

class VehicleController extends Controller {
  public function create() {
    $vehicle = new Vehicle();
    $spots = $vehicle->spots();
    $this->render('vehicle_entry', compact('spots'));
  }

  public function store() {
    $plate = trim($_POST['plate'] ?? '');
    $spot  = trim($_POST['spot'] ?? '');
    $ok = (new Vehicle())->insert($plate, $spot);
    if ($ok) {
      header('Location: ?route=vehicle-entry&saved=1');
    } else {
      header('Location: ?route=vehicle-entry&error=1');
    }
    exit;
  }

  public function insideList() {
    $page = max(1, (int)($_GET['page'] ?? 1));
    $vehicle = new Vehicle();
    $rows = $vehicle->insidePaged($page);
    $total = $vehicle->insideCount();
    $per = 8;
    $pages = max(1, (int)ceil($total/$per));
    $this->render('inside_list', compact('rows','page','pages'));
  }

  public function exitForm() {
    $vehicle = new Vehicle();
    $inside = $vehicle->allInside();
    $this->render('vehicle_exit', compact('inside'));
  }

  public function exitStore() {
    $plate = $_POST['plate'] ?? '';
    $vehicle = new Vehicle();
    $ok = $vehicle->exitVehicle($plate);
    header('Location: ?route=vehicle-exit&done=' . ($ok?1:0));
    exit;
  }
}