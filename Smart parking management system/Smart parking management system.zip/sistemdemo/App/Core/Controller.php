<?php
namespace App\Core;

class Controller {
  protected function render(string $view, array $data = []) {
    extract($data);
    $contentView = __DIR__ . '/../Views/' . $view . '.php';
    require __DIR__ . '/../Views/layout.php';
  }
  public function store() {
    $plate = trim($_POST['plate'] ?? '');
    $spot  = trim($_POST['spot'] ?? '');
    $ok = (new Vehicle())->insert($plate, $spot);
    if ($ok) {
        header('Location: ?route=vehicle-entry&saved=1');
    } else {
        header('Location: ?route=vehicle-entry&error=1');
    }
    exit;
}
}