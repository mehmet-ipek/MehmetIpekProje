<?php
namespace App\Core;

class Model {
  protected \PDO $db;
  public function __construct() {
    $this->db = Database::get();
  }
}