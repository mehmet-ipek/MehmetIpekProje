<?php
namespace App\Models;

use App\Core\Model;

class Sketch extends Model {
  public function insert(string $name, int $w, int $l, int $cap): bool {
    $stmt = $this->db->prepare("INSERT INTO sketches (name, width, length, capacity) VALUES (?, ?, ?, ?)");
    return $stmt->execute([$name, $w, $l, $cap]);
  }
}