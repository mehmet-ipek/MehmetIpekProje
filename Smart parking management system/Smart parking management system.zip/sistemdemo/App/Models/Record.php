<?php
namespace App\Models;

use App\Core\Model;

class Record extends Model {
  public function totalEntries(): int {
    $r = (int) $this->db->query("SELECT COUNT(*) AS c FROM records")->fetch()['c'];
    $v = (int) $this->db->query("SELECT COUNT(*) AS c FROM vehicles")->fetch()['c'];
    return $r + $v;
  }

  public function historyFiltered(?string $from, ?string $to, ?string $plate): array {
    $sql = "SELECT plate,
                   TIMESTAMPDIFF(MINUTE, entry_at, exit_at) AS mins,
                   entry_at, exit_at, spot_code
            FROM records WHERE 1=1";
    $params = [];
    if ($from) { $sql .= " AND DATE(entry_at) >= ?"; $params[] = $from; }
    if ($to)   { $sql .= " AND DATE(exit_at) <= ?"; $params[] = $to; }
    if ($plate){ $sql .= " AND plate LIKE ?"; $params[] = '%'.$plate.'%'; }
    $sql .= " ORDER BY entry_at DESC LIMIT 100";
    $stmt = $this->db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
  }

  public function dailyCountsForChart(): array {
    $rows = $this->db->query("
      SELECT DATE(entry_at) AS d, COUNT(*) AS c
      FROM (
        SELECT entry_at FROM records
        UNION ALL
        SELECT entry_at FROM vehicles
      ) t
      GROUP BY DATE(entry_at)
      ORDER BY d
    ")->fetchAll();

    if (empty($rows)) {
      $out = [];
      for ($i=0;$i<10;$i++) {
        $d = date('Y-m-d', strtotime("-$i days"));
        $out[] = ['d'=>$d, 'c'=>0];
      }
      return array_reverse($out);
    }
    return $rows;
  }
}