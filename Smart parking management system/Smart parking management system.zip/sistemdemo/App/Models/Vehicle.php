<?php
namespace App\Models;

use PDO;

use App\Core\Model;

class Vehicle extends Model {
  public function countInside(): int {
    return (int) $this->db->query("SELECT COUNT(*) AS c FROM vehicles")->fetch()['c'];
  }

  public function capacity(): int {
    $row = $this->db->query("SELECT COALESCE(capacity,100) AS cap FROM sketches ORDER BY id DESC LIMIT 1")->fetch();
    return (int)($row['cap'] ?? 100);
  }

  public function insert(string $plate, string $spot): bool {
    // Aynı plakadan içeride var mı?
    $stmt = $this->db->prepare("SELECT COUNT(*) AS c FROM vehicles WHERE plate = ?");
    $stmt->execute([$plate]);
    if ($stmt->fetch()['c'] > 0) return false;

    // Aynı park yeri dolu mu?
    $stmt = $this->db->prepare("SELECT COUNT(*) AS c FROM vehicles WHERE spot_code = ?");
    $stmt->execute([$spot]);
    if ($stmt->fetch()['c'] > 0) return false;

    // Kapasite kontrolü
    $current = $this->countInside();
    $capacity = $this->capacity();
    if ($current >= $capacity) return false;

    // ekle
    $stmt = $this->db->prepare("INSERT INTO vehicles (plate, spot_code, entry_at) VALUES (?, ?, NOW())");
    return $stmt->execute([$plate, $spot]);
}

  public function spots(): array {
    return $this->db->query("SELECT code FROM spots ORDER BY code")->fetchAll();
  }

  public function insidePaged(int $page=1, int $per=8): array {
    $offset = ($page-1)*$per;
    $rows = $this->db->prepare("SELECT plate, TIMESTAMPDIFF(MINUTE, entry_at, NOW()) AS mins, entry_at, spot_code
                                FROM vehicles ORDER BY entry_at DESC LIMIT ? OFFSET ?");
    $rows->bindValue(1, $per, \PDO::PARAM_INT);
    $rows->bindValue(2, $offset, \PDO::PARAM_INT);
    $rows->execute();
    return $rows->fetchAll();
  }

  public function insideCount(): int {
    return (int) $this->db->query("SELECT COUNT(*) AS c FROM vehicles")->fetch()['c'];
  }

  public function searchPlate(string $q): array {
    $stmt = $this->db->prepare("SELECT plate, spot_code, entry_at FROM vehicles WHERE plate LIKE ?");
    $stmt->execute(['%'.$q.'%']);
    return $stmt->fetchAll();
  }

  public function allInside(): array {
    return $this->db->query("SELECT plate, spot_code, entry_at FROM vehicles")->fetchAll();
  }

  public function exitVehicle(string $plate): bool {
    $stmt = $this->db->prepare("SELECT * FROM vehicles WHERE plate=? LIMIT 1");
    $stmt->execute([$plate]);
    $row = $stmt->fetch();
    if (!$row) return false;

    $stmt = $this->db->prepare("INSERT INTO records (plate, entry_at, exit_at, spot_code) VALUES (?,?,NOW(),?)");
    $stmt->execute([$row['plate'], $row['entry_at'], $row['spot_code']]);

    $stmt = $this->db->prepare("DELETE FROM vehicles WHERE plate=?");
    return $stmt->execute([$plate]);
  }
  public function spotStatus(): array {
    $all = $this->db->query("SELECT code FROM spots ORDER BY code")->fetchAll();
    $occupied = $this->db->query("SELECT spot_code FROM vehicles")->fetchAll(PDO::FETCH_COLUMN);
    $result = [];
    foreach ($all as $s) {
        $code = $s['code'];
        $result[] = [
            'code' => $code,
            'status' => in_array($code, $occupied) ? 'dolu' : 'bos'
        ];
    }
    return $result;
  }
}