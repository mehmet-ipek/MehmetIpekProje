<?php
return [
  'db' => [
    'host' => '127.0.0.1',
    'name' => 'smart_parking',
    'user' => 'root',
    'pass' => '',
    'charset' => 'utf8mb4'
  ]
];