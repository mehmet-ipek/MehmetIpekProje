
CREATE DATABASE IF NOT EXISTS smart_parking CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smart_parking;

-- Parking sketch (layout)
CREATE TABLE sketches (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  width INT NOT NULL,
  length INT NOT NULL,
  capacity INT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Parking spots (optional; kept simple)
CREATE TABLE spots (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(20) NOT NULL UNIQUE, -- e.g., A1, A2, B1...
  sketch_id INT NULL,
  FOREIGN KEY (sketch_id) REFERENCES sketches(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Vehicles currently inside
CREATE TABLE vehicles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  plate VARCHAR(20) NOT NULL,
  spot_code VARCHAR(20) NOT NULL,
  entry_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Historical records (entry/exit)
CREATE TABLE records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  plate VARCHAR(20) NOT NULL,
  entry_at DATETIME NOT NULL,
  exit_at DATETIME NOT NULL,
  spot_code VARCHAR(20) NOT NULL
) ENGINE=InnoDB;

-- Seed sample
INSERT INTO sketches (name, width, length, capacity) VALUES
('Default Layout', 50, 100, 100);

INSERT INTO spots (code, sketch_id) VALUES
('A1', 1), ('A2', 1), ('A3', 1), ('B1', 1), ('B2', 1), ('B3', 1);

-- Simulate inside vehicles
INSERT INTO vehicles (plate, spot_code, entry_at) VALUES
('34 AB 2525', 'A3', '2017-02-20 10:30:00'),
('34 CB 0953', 'B1', '2017-02-20 10:30:00');

-- Historical sample records (matching screenshots)
INSERT INTO records (plate, entry_at, exit_at, spot_code) VALUES
('34 AB 2525', '2017-02-20 10:30:00', '2017-02-20 12:45:00', 'A3'),
('34 AB 2525', '2017-02-20 10:30:00', '2017-02-20 12:45:00', 'A3'),
('34 AB 2525', '2017-02-20 10:30:00', '2017-02-20 12:45:00', 'A3'),
('34 AB 2525', '2017-02-20 10:30:00', '2017-02-20 12:45:00', 'A3'),
('34 CD 9853', '2017-02-20 10:30:00', '2017-02-20 11:40:00', 'B1'),
('34 CD 9853', '2017-02-20 10:30:00', '2017-02-20 11:40:00', 'B1'),
('34 CD 9853', '2017-02-20 10:30:00', '2017-02-20 11:40:00', 'B1'),
('34 CD 9853', '2017-02-20 10:30:00', '2017-02-20 11:40:00', 'B1');